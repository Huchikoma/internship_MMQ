configureAutocomplete = function(moduleOptions) {
    $(document).find('.mod_autocomplete input').autocomplete(moduleOptions);
}