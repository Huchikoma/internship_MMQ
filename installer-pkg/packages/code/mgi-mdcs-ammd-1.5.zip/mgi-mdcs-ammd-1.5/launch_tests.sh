#!/bin/bash
python manage.py test mgi/ user_dashboard/ api/ --liveserver=localhost:8082