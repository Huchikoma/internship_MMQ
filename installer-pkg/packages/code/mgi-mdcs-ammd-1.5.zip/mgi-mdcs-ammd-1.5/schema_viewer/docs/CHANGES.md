# Schema Viewer package - Release history

## Version 0.0.3

* Ability to view the <oXygen/> documentation

## Version 0.0.2

* Ability to download the schema
* Better CSS for the schema

## Version 0.0.1

* Basic schema viewer
* A simple XSLT transforming the schema
