use mgi
db.createUser({
user: "mgi_user",
pwd: "mgi_password",
roles: ["readWrite"]})
exit