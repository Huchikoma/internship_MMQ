#!/bin/bash
radon cc --total-average **/*.py --xml > radon.xml