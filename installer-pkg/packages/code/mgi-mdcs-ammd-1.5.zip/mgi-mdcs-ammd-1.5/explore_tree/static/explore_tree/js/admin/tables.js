$("#available-owl-table").tablesorter();
$("#deleted-owl-table").tablesorter();