# Explore tree package - Release history

## Version 0.1.1

* Bugfix: Cancel OWL upload not working correctly

-----

## Version 0.1.0

* Added hidden element from the tree
* Highlighted element being viewed

-----

## Version 0.0.2

* Full ontology management (upload, activation, download, deletion)
* Complex queries to the database (cross-queries between document)
* Link between views together

-----

## Version 0.0.1

* Simple ontology management (upload and activation)
* Display of the class tree from the ontology
* Display of simple views on the
* Simple query to the database
