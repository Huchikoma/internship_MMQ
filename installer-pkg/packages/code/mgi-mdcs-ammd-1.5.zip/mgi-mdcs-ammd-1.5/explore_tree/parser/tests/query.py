"""

"""
from django.test.testcases import TestCase


class ParserQueryTestCase(TestCase):
    """

    """
    def setUp(self):
        pass

    def test_simple_query(self):
        pass

    def test_advanced_query(self):
        pass
